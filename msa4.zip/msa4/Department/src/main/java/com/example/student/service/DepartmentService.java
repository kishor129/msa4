package com.example.student.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.student.entity.Department;
import com.example.student.vo.RequestTemplate;

@Service
public interface DepartmentService {
	Department add(Department dept);
	List<Department>list();
	Department update(long id,String name);
	Department searchById(long id);
	List<RequestTemplate>listWithEmp();
	RequestTemplate spaceficDepartmentEmployee(long dept_id);
}

	
