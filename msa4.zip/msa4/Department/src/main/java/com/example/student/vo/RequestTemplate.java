package com.example.student.vo;

import java.util.ArrayList;
import java.util.List;

import com.example.student.entity.Department;

public class RequestTemplate {
	private List<Employee>employeeList=new ArrayList<Employee>();
	private Department department;
	
	public RequestTemplate(Department department,List<Employee>employeeList) {
		super();
		this.department=department;
		this.employeeList=employeeList;
	}

	public List<Employee> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public RequestTemplate() {
		super();
	}
	

}
