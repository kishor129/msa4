package com.example.student;

public class RestTemplete {

}
