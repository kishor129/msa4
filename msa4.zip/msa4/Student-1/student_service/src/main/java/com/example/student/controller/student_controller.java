package com.example.student.controller;


import org.jboss.logging.BasicLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.student.entity.student;
import com.example.student.service.ResponseTemplatevo;
import com.example.student.service.student_service;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/std")
@Slf4j
public class student_controller {
	@Autowired
	private student_service stdser;
	@PostMapping
	public student savestudent(@RequestBody student std) {
		BasicLogger log;
		
		return stdser.savestudent(std);
		
	}
	@GetMapping("/{id}")
	public ResponseTemplatevo getStudent(Long id) {
		return student_service.getstudentincollege(id);
		
	}

}
