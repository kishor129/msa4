package com.example.student.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public
class student {
	@Id
	private long roolnor;
	private String name;
	private String gender;
	private int age;

}
