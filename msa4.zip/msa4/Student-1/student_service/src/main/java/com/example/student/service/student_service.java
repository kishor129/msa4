package com.example.student.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;


import com.example.student.entity.student;
import com.example.student.repository.student_repostitory;

public class student_service {
	@Autowired
	private static student_repostitory stdrepo;
	private static Object userRepositorry;

	public static student savestudent(student std) {
		// TODO Auto-generated method stub
		
			return stdrepo.save(std);
		
	}

	public static ResponseTemplatevo getstudentincollege(Long id) {
		// TODO Auto-generated method stub
		ResponseTempletevo vo=new ResponseTempletevo();
	   student std=((Object) userRepositorry).findbystudentid(id);
	}

}
