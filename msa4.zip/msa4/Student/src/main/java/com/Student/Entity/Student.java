package com.Student.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	private String name;
	private String Steam;
	private String gender;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSteam() {
		return Steam;
	}
	public void setSteam(String steam) {
		Steam = steam;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Student(String name, String steam, String gender, int age) {
		super();
		this.name = name;
		Steam = steam;
		this.gender = gender;
		this.age = age;
	}
	public Student() {
		super();
	}
	

}
