package com.Student.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Student.Entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student,String  >{
Optional<Student> findById(String name);
}
