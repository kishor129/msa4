package com.Student.Vo;

public class College {
private String name;
private int totalStudent;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getTotalStudent() {
	return totalStudent;
}
public void setTotalStudent(int totalStudent) {
	this.totalStudent = totalStudent;
}
public College(String name, int totalStudent) {
	super();
	this.name = name;
	this.totalStudent = totalStudent;
}
public College() {
	super();
}


}
