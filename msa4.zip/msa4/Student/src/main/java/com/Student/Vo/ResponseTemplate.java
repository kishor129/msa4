package com.Student.Vo;

import com.Student.Entity.Student;

public class ResponseTemplate {
	private Student student;
	private College college;
	public Student getStudent() {
		return student;
	}
	public College getCollege() {
		return college;
	}
	public ResponseTemplate(Student student, College college) {
		super();
		this.student = student;
		this.college = college;
	}
	public ResponseTemplate() {
		super();
	}

}
