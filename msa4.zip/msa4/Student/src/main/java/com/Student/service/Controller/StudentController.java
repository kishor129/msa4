package com.Student.service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Student.Entity.Student;
import com.Student.Vo.ResponseTemplate;
import com.Student.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {

	
	@Autowired
	StudentService stdservice;
	
	@PostMapping
	public Student add(@RequestBody Student std) {
		return stdservice.add(std);
	}
	
	@GetMapping
	public List<Student>liststd(){
		return stdservice.list();
	}
	
	
	@GetMapping("{stdName}")
	public ResponseTemplate stdWithColl(@PathVariable String name) {
		return stdservice.stdWithcoll(name);
	}
	
	
	@PutMapping ("/{stdName}")
		public String updateCollege(@PathVariable String name) {
		Student std=stdservice.assignCollege(name);
		if(std!=null) {
			return std.toString();
			
		}
		return "sorry.College or Student not found ";
	}
	@GetMapping("/student-withdesc-age/{name)")
	public List<Student>getStudentByCollegeWithDescAge(@PathVariable String name){
		return stdservice.getstudentByDeparmentWithDescAge(name);
	}
}
