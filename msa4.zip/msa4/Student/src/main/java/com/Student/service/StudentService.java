package com.Student.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Student.Entity.Student;
import com.Student.Vo.ResponseTemplate;

@Service
public interface StudentService {
Student add(Student std);
List<Student>list();
Student serchByName(String name);
ResponseTemplate stdWithcoll(String name);
Student assignDepartment(String name,String Stream);
List<Student>getByName(String name);
List<Student>getstudentByDeparmentWithDescAge(String name);
Student assignCollege(String name);
}
